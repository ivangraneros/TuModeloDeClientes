# clientes_compras

Un pequeño paquete para modelar clientes en una tienda de compras usando Programación Orientada a Objetos.

## Uso

```python
from clientes_compras import Cliente

cliente1 = Cliente("Juan Pérez", "juan@email.com", "Calle Falsa 123", "123456789")
cliente1.agregar_producto("Laptop")
cliente1.mostrar_carrito()