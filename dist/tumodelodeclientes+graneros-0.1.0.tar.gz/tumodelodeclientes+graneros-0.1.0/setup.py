from setuptools import setup, find_packages

setup(
    name="TuModeloDeClientes+Graneros",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Ivan Graneros",
    description="Paquete para modelar clientes en una página de compras",
)